#include"helloworld.h"
int main(){
	hello();
}
