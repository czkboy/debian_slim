#include <iostream>
#include "helloworld.h"
void hello(){
    std::cout<<"helloworld"<<std::endl;
}