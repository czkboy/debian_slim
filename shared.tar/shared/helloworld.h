#ifndef __HEPPLWPRLD_H__
#define __HEPPLWPRLD_H__

void hello();

#endif
